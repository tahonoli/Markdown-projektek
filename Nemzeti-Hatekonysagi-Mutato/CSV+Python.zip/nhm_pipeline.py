
"""NHM pipeline (HU vs PL) – reproducible demo
Seed: 42
Hyperparams:
- Normalization: min–max to 0–100 (direction-preserving)
- Ensemble: average of (equal-weight pillar means, PCA(1)-based score, rank-average), all rescaled to 0–100
- k-fold: 10 folds, metric (pillar) dropout: 20% per fold
- Sensitivity: (a) all-50 except X=100; (b) leave-one-pillar-out deltas
- Shapley-like: average marginal contribution over k=10 random subsets
Notes:
- PCA and rank components include degenerate-safe fallbacks (50-50) when variance across countries collapses.
- This is a proxy-based demonstration; swap the 'data' dict with real metrics to go live.
"""

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
import random

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# --- Input proxy data (pillars) ---
data = {
    "Pillér": [
        "1. Erőforrás- és adottságbázis (INPUT)",
        "2. Intézményi minőség & jogállamiság (INPUT)",
        "3. Átalakítási hatékonyság (PROCESS)",
        "4. Tudás- és innovációs kapacitás (PROCESS)",
        "5. Piaci integráció & nemzetközi súly (OUTPUT)",
        "6. Társadalmi kimenetek & jóléti minőség (OUTCOME)",
        "7. Fenntarthatóság & kockázati korrekció (RISK)",
        "8. Rezíliencia & koordinációs képesség (ADAPT)",
    ],
    "HU_raw": [0.55, 0.35, 0.45, 0.55, 0.50, 0.50, 0.45, 0.45],
    "PL_raw": [0.65, 0.50, 0.60, 0.55, 0.70, 0.60, 0.60, 0.60],
}
df = pd.DataFrame(data)

def normalize(series):
    min_val, max_val = series.min(), series.max()
    if max_val > min_val:
        return 100 * (series - min_val) / (max_val - min_val)
    return pd.Series([50]*len(series), index=series.index)

df["HU_norm"] = normalize(df["HU_raw"])
df["PL_norm"] = normalize(df["PL_raw"])

# --- Ensemble scoring over pillars x countries matrix ---
def ensemble_from_matrix(mat_df):
    kept = mat_df[["HU_norm", "PL_norm"]].copy()
    # (1) Equal-weight
    eq = kept.mean(axis=0)
    eq_norm = (eq / eq.max()) * 100 if eq.max() > 0 else eq * 0 + 50.0

    # (2) PCA(1)
    pca = PCA(n_components=1, random_state=SEED)
    vals = pca.fit_transform(kept.T)
    if float(vals.max() - vals.min()) == 0.0:
        pca_scaled = np.array([[50.0],[50.0]])
    else:
        pca_scaled = 100 * (vals - vals.min()) / (vals.max() - vals.min())
    pca_scores = {"HU_norm": float(pca_scaled[0]), "PL_norm": float(pca_scaled[1])}

    # (3) Rank-average
    ranks = kept.rank(axis=1, method="average")
    rank_means = ranks.mean(axis=0)
    if float(rank_means.max() - rank_means.min()) == 0.0:
        rank_scaled = (rank_means * 0) + 50.0
    else:
        rank_scaled = 100 * (rank_means - rank_means.min()) / (rank_means.max() - rank_means.min())

    scores = {
        "HU": np.mean([eq_norm["HU_norm"], pca_scores["HU_norm"], rank_scaled["HU_norm"]]),
        "PL": np.mean([eq_norm["PL_norm"], pca_scores["PL_norm"], rank_scaled["PL_norm"]]),
    }
    return scores

# --- Baseline ensemble ---
baseline_scores = ensemble_from_matrix(df[["HU_norm", "PL_norm"]])
baseline_df = pd.DataFrame([
    {"Method": "Ensemble", "HU": baseline_scores["HU"], "PL": baseline_scores["PL"]}
])

# --- k-fold with 20% pillar dropout ---
k_folds = 10
dropout_rate = 0.2
fold_results = []
for fold in range(k_folds):
    n_drop = max(1, int(len(df) * dropout_rate))
    drop_indices = random.sample(range(len(df)), n_drop)
    kept = df.drop(index=drop_indices)[["HU_norm", "PL_norm"]]
    fold_scores = ensemble_from_matrix(kept)
    fold_results.append(fold_scores)
fold_df = pd.DataFrame(fold_results)

# --- Sensitivity ---
# (a) All=50 except X=100
pillars_list = df["Pillér"].tolist()
spike_records = []
for i, pillar in enumerate(pillars_list):
    test_matrix = pd.DataFrame({"HU_norm": [50]*len(pillars_list),
                                "PL_norm": [50]*len(pillars_list)})
    test_matrix.iloc[i] = [100, 100]
    scr = ensemble_from_matrix(test_matrix)
    spike_records.append({"Pillér": pillar, "HU": scr["HU"], "PL": scr["PL"]})
df_spikes = pd.DataFrame(spike_records)

# (b) Leave-one-pillar-out deltas
leaveout_records = []
for i, pillar in enumerate(pillars_list):
    reduced = df.drop(index=i)[["HU_norm", "PL_norm"]]
    scr = ensemble_from_matrix(reduced)
    leaveout_records.append({"Pillér": pillar, "HU_delta": scr["HU"]-baseline_scores["HU"],
                             "PL_delta": scr["PL"]-baseline_scores["PL"]})
df_leaveout = pd.DataFrame(leaveout_records)

# --- Shapley-like pillar contributions ---
def shapley_like(pillars_norm, k=10):
    records = []
    for idx in range(len(pillars_norm)):
        diffs_HU, diffs_PL = [], []
        for _ in range(k):
            remaining_idx = [j for j in range(len(pillars_norm)) if j != idx]
            subset_size = max(1, int(round(0.8 * len(remaining_idx))))
            S = sorted(random.sample(remaining_idx, subset_size))
            mat_S = pillars_norm.loc[S, ["HU_norm", "PL_norm"]]
            mat_S_plus = pillars_norm.loc[sorted(S + [idx]), ["HU_norm", "PL_norm"]]
            f_S = ensemble_from_matrix(mat_S)
            f_S_plus = ensemble_from_matrix(mat_S_plus)
            diffs_HU.append(f_S_plus["HU"] - f_S["HU"])
            diffs_PL.append(f_S_plus["PL"] - f_S["PL"])
        records.append({
            "Pillér": pillars_norm.loc[idx, "Pillér"],
            "HU_contrib": np.mean(diffs_HU),
            "PL_contrib": np.mean(diffs_PL),
        })
    out = pd.DataFrame(records)
    for c in ["HU_contrib", "PL_contrib"]:
        total_abs = out[c].abs().sum()
        out[c.replace("_contrib", "_share_%")] = 0.0 if total_abs==0 else 100*out[c].abs()/total_abs
    return out

pillars_norm = df[["Pillér","HU_norm","PL_norm"]].reset_index(drop=True)
contrib_df = shapley_like(pillars_norm, k=10)

# --- Save outputs ---
df.to_csv("/mnt/data/NHM_proxy_normalized.csv", index=False)
baseline_df.to_csv("/mnt/data/NHM_ensemble_results.csv", index=False)
fold_df.to_csv("/mnt/data/NHM_kfold_results.csv", index=False)
pillars_norm.to_csv("/mnt/data/NHM_pillars_norm.csv", index=False)
df_spikes.to_csv("/mnt/data/NHM_sensitivity_spikes.csv", index=False)
df_leaveout.to_csv("/mnt/data/NHM_sensitivity_leaveout.csv", index=False)
contrib_df.to_csv("/mnt/data/NHM_pillar_contributions.csv", index=False)

print("Done. Files saved to /mnt/data.")
